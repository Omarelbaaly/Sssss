import React, { useState } from 'react';
import { AppData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Download, Printer, Filter } from 'lucide-react';

interface ReportsProps {
  data: AppData;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export const Reports: React.FC<ReportsProps> = ({ data }) => {
  const [filterType, setFilterType] = useState<'ALL' | 'IN' | 'OUT'>('ALL');
  
  const transactions = data.transactions.filter(t => filterType === 'ALL' || t.type === filterType);
  
  // Prepare Chart Data
  const categoryData = data.items.reduce((acc, item) => {
    const existing = acc.find(x => x.name === item.category);
    if (existing) {
      existing.value += 1;
    } else {
      acc.push({ name: item.category, value: 1 });
    }
    return acc;
  }, [] as any[]);

  const movementData = data.transactions.slice(-10).map(t => ({
    name: t.date.slice(5), // Month-Day
    quantity: t.quantity,
    type: t.type === 'IN' ? 'وارد' : 'منصرف'
  }));

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center no-print">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">التقارير والإحصائيات</h2>
          <p className="text-gray-500">تحليل حركات الوارد والمنصرف</p>
        </div>
        <button 
          onClick={handlePrint}
          className="flex items-center gap-2 bg-slate-800 text-white px-4 py-2 rounded-lg hover:bg-slate-900 transition"
        >
          <Printer size={18} />
          <span>طباعة / PDF</span>
        </button>
      </div>

      {/* Charts Section - Hidden on small print sizes often, but we keep it */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 no-print">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-700 mb-4">توزيع الأصناف حسب الفئة</h3>
            <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                        <Pie
                            data={categoryData}
                            cx="50%"
                            cy="50%"
                            innerRadius={60}
                            outerRadius={80}
                            paddingAngle={5}
                            dataKey="value"
                        >
                            {categoryData.map((entry, index) => (
                                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                            ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                    </PieChart>
                </ResponsiveContainer>
            </div>
        </div>

        <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <h3 className="font-bold text-gray-700 mb-4">آخر 10 حركات</h3>
            <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={movementData}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Bar dataKey="quantity" fill="#f97316" radius={[4, 4, 0, 0]} name="الكمية" />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
      </div>

      {/* Detailed Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden print:shadow-none print:border-none">
        <div className="p-6 border-b border-gray-50 flex justify-between items-center bg-gray-50 print:bg-white">
            <h3 className="font-bold text-gray-800">سجل العمليات التفصيلي</h3>
            <div className="flex gap-2 no-print">
                <button onClick={() => setFilterType('ALL')} className={`px-3 py-1 rounded text-sm ${filterType === 'ALL' ? 'bg-white shadow text-primary-600' : 'text-gray-500'}`}>الكل</button>
                <button onClick={() => setFilterType('IN')} className={`px-3 py-1 rounded text-sm ${filterType === 'IN' ? 'bg-white shadow text-emerald-600' : 'text-gray-500'}`}>وارد</button>
                <button onClick={() => setFilterType('OUT')} className={`px-3 py-1 rounded text-sm ${filterType === 'OUT' ? 'bg-white shadow text-orange-600' : 'text-gray-500'}`}>منصرف</button>
            </div>
        </div>
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
                <thead className="bg-gray-50 text-gray-500 font-medium border-b print:bg-gray-100">
                    <tr>
                        <th className="p-4">#</th>
                        <th className="p-4">التاريخ</th>
                        <th className="p-4">النوع</th>
                        <th className="p-4">الصنف</th>
                        <th className="p-4">الكمية</th>
                        <th className="p-4">الطرف الثاني</th>
                        <th className="p-4">ملاحظات</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {transactions.slice().reverse().map((t, idx) => (
                        <tr key={t.id} className="hover:bg-gray-50 print:hover:bg-white">
                            <td className="p-4 text-gray-400">{transactions.length - idx}</td>
                            <td className="p-4 text-gray-600">{t.date}</td>
                            <td className="p-4">
                                <span className={`px-2 py-1 rounded text-xs font-bold border ${
                                    t.type === 'IN' 
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-100' 
                                    : 'bg-orange-50 text-orange-700 border-orange-100'
                                }`}>
                                    {t.type === 'IN' ? 'وارد' : 'منصرف'}
                                </span>
                            </td>
                            <td className="p-4 font-bold text-gray-800">{t.itemName}</td>
                            <td className="p-4 font-mono text-base">{t.quantity}</td>
                            <td className="p-4 text-gray-600">{t.party}</td>
                            <td className="p-4 text-gray-400 max-w-xs truncate">{t.notes || '-'}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};