import React, { useState } from 'react';
import { AppData, TransactionType } from '../types';
import { Save, Search, Calendar, User, Package, Hash } from 'lucide-react';

interface TransactionFormProps {
  type: TransactionType;
  data: AppData;
  onSubmit: (transactionData: any) => void;
}

export const TransactionForm: React.FC<TransactionFormProps> = ({ type, data, onSubmit }) => {
  const [itemId, setItemId] = useState('');
  const [quantity, setQuantity] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [party, setParty] = useState('');
  const [notes, setNotes] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Derived state
  const selectedItem = data.items.find(i => i.id === itemId);
  const filteredItems = data.items.filter(i => i.name.toLowerCase().includes(searchTerm.toLowerCase()));

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemId || !quantity || !party) return;

    // Validation for outbound
    if (type === 'OUT' && selectedItem) {
        if (Number(quantity) > selectedItem.currentStock) {
            alert(`خطأ: الكمية المطلوبة (${quantity}) أكبر من الرصيد المتاح (${selectedItem.currentStock})`);
            return;
        }
    }

    onSubmit({
      itemId,
      itemName: selectedItem?.name || 'Unknown',
      type,
      quantity: Number(quantity),
      date,
      party,
      notes
    });

    // Reset basics
    setQuantity('');
    setNotes('');
  };

  const isTypeIn = type === 'IN';
  const themeColor = isTypeIn ? 'emerald' : 'orange';
  const themeBg = isTypeIn ? 'bg-emerald-600' : 'bg-orange-600';
  const themeBgHover = isTypeIn ? 'hover:bg-emerald-700' : 'hover:bg-orange-700';

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h2 className="text-2xl font-bold text-gray-800">
            {isTypeIn ? 'تسجيل وارد جديد' : 'تسجيل منصرف (سحب)'}
        </h2>
        <p className="text-gray-500">
            {isTypeIn ? 'إضافة كميات للمخزون من الموردين' : 'صرف مواد للمشاريع أو العملاء'}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Col: Form */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
            <form onSubmit={handleSubmit} className="space-y-6">
                
                {/* Item Selection */}
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">اختر الصنف</label>
                    <div className="relative">
                        <Search className="absolute right-3 top-3 text-gray-400" size={18} />
                        <input 
                            type="text"
                            placeholder="ابحث عن الصنف..."
                            className="w-full pr-10 pl-3 py-2 border rounded-lg mb-2 text-sm focus:outline-none focus:border-primary-400"
                            value={searchTerm}
                            onChange={e => setSearchTerm(e.target.value)}
                        />
                        <select 
                            required 
                            className="w-full p-3 rounded-lg border bg-gray-50 focus:bg-white focus:ring-2 focus:ring-primary-100 outline-none transition cursor-pointer"
                            value={itemId}
                            onChange={e => setItemId(e.target.value)}
                            size={5} // Show as list
                        >
                            <option value="" disabled className="text-gray-400">-- اختر من القائمة --</option>
                            {filteredItems.map(item => (
                                <option key={item.id} value={item.id} className="p-2 border-b border-gray-100 last:border-0 hover:bg-gray-100 cursor-pointer">
                                    {item.name} (المتاح: {item.currentStock} {item.unit})
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                            <Hash size={16} />
                            <span>الكمية</span>
                        </label>
                        <input 
                            required 
                            type="number" 
                            min="1"
                            step="0.01"
                            placeholder="0.00"
                            className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-100 outline-none"
                            value={quantity}
                            onChange={e => setQuantity(e.target.value)}
                        />
                    </div>
                    <div>
                        <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                            <Calendar size={16} />
                            <span>التاريخ</span>
                        </label>
                        <input 
                            required 
                            type="date" 
                            className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-100 outline-none"
                            value={date}
                            onChange={e => setDate(e.target.value)}
                        />
                    </div>
                </div>

                <div>
                    <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                        <User size={16} />
                        <span>{isTypeIn ? 'المورد / المصدر' : 'المستلم / المشروع'}</span>
                    </label>
                    <input 
                        required 
                        type="text" 
                        placeholder={isTypeIn ? 'مثال: شركة الأسمنت الوطنية' : 'مثال: المهندس أحمد - مشروع أ'}
                        className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-100 outline-none"
                        value={party}
                        onChange={e => setParty(e.target.value)}
                    />
                </div>

                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">ملاحظات (اختياري)</label>
                    <textarea 
                        rows={3}
                        className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-100 outline-none resize-none"
                        value={notes}
                        onChange={e => setNotes(e.target.value)}
                    ></textarea>
                </div>

                <button 
                    type="submit" 
                    className={`w-full ${themeBg} text-white py-4 rounded-xl font-bold ${themeBgHover} transition flex justify-center items-center gap-2 shadow-lg opacity-90 hover:opacity-100`}
                >
                    <Save size={20} />
                    <span>حفظ العملية</span>
                </button>
            </form>
        </div>

        {/* Right Col: Preview & Info */}
        <div className="space-y-6">
            <div className={`p-6 rounded-2xl ${isTypeIn ? 'bg-emerald-50 border-emerald-100' : 'bg-orange-50 border-orange-100'} border`}>
                <h3 className={`font-bold text-lg mb-2 ${isTypeIn ? 'text-emerald-800' : 'text-orange-800'}`}>معلومات العملية</h3>
                <div className="space-y-4 text-sm opacity-80">
                    <p>أنت تقوم بتسجيل حركة <span className="font-bold">{isTypeIn ? 'واردة (إضافة)' : 'صادرة (خصم)'}</span>.</p>
                    <p>سيتم تحديث رصيد الصنف تلقائياً فور الحفظ.</p>
                </div>
            </div>

            {selectedItem && (
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
                    <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                        <Package size={18} className="text-primary-500" />
                        ملخص الصنف المحدد
                    </h4>
                    <div className="space-y-3">
                        <div className="flex justify-between border-b border-gray-50 pb-2">
                            <span className="text-gray-500">الاسم</span>
                            <span className="font-medium">{selectedItem.name}</span>
                        </div>
                        <div className="flex justify-between border-b border-gray-50 pb-2">
                            <span className="text-gray-500">الرصيد الحالي</span>
                            <span className="font-bold text-lg">{selectedItem.currentStock} {selectedItem.unit}</span>
                        </div>
                        <div className="flex justify-between border-b border-gray-50 pb-2">
                            <span className="text-gray-500">الفئة</span>
                            <span>{selectedItem.category}</span>
                        </div>
                        
                        {/* Outbound Preview Calculation */}
                        {!isTypeIn && quantity && (
                            <div className="mt-4 bg-gray-50 p-3 rounded-lg">
                                <div className="flex justify-between text-sm">
                                    <span>الرصيد بعد الصرف:</span>
                                    <span className={`font-bold ${selectedItem.currentStock - Number(quantity) < 0 ? 'text-red-600' : 'text-gray-800'}`}>
                                        {selectedItem.currentStock - Number(quantity)} {selectedItem.unit}
                                    </span>
                                </div>
                            </div>
                        )}
                    </div>
                 </div>
            )}
        </div>
      </div>
    </div>
  );
};