import React, { useState } from 'react';
import { Item, AppData } from '../types';
import { Search, Plus, Edit2, Trash2, AlertTriangle, Save, X } from 'lucide-react';

interface InventoryProps {
  data: AppData;
  onAddItem: (item: Item) => void;
  onUpdateItem: (item: Item) => void;
  onDeleteItem: (id: string) => void;
}

export const Inventory: React.FC<InventoryProps> = ({ data, onAddItem, onUpdateItem, onDeleteItem }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<Item | null>(null);

  // Form State
  const [formData, setFormData] = useState<Partial<Item>>({
    name: '', category: '', minStockLevel: 0, unit: 'قطعة', currentStock: 0
  });

  const filteredItems = data.items.filter(item => 
    item.name.includes(searchTerm) || item.category.includes(searchTerm)
  );

  const handleOpenModal = (item?: Item) => {
    if (item) {
      setEditingItem(item);
      setFormData(item);
    } else {
      setEditingItem(null);
      setFormData({ name: '', category: '', minStockLevel: 10, unit: 'قطعة', currentStock: 0 });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name) return;

    if (editingItem) {
      onUpdateItem({ ...editingItem, ...formData } as Item);
    } else {
      onAddItem({
        id: Date.now().toString(),
        ...formData
      } as Item);
    }
    setIsModalOpen(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">الأصناف والمخزون</h2>
          <p className="text-gray-500">إدارة المواد ومراقبة الكميات الحالية</p>
        </div>
        <button 
          onClick={() => handleOpenModal()}
          className="flex items-center gap-2 bg-primary-600 text-white px-5 py-2.5 rounded-xl hover:bg-primary-700 transition shadow-lg shadow-primary-500/30"
        >
          <Plus size={20} />
          <span>إضافة صنف</span>
        </button>
      </div>

      <div className="relative">
        <Search className="absolute right-4 top-3.5 text-gray-400" size={20} />
        <input 
          type="text" 
          placeholder="بحث باسم الصنف أو الفئة..." 
          className="w-full pr-12 pl-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 outline-none transition"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredItems.map(item => (
          <div key={item.id} className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition group">
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 rounded-full bg-gray-50 flex items-center justify-center text-xl font-bold text-gray-600">
                {item.name.charAt(0)}
              </div>
              <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button onClick={() => handleOpenModal(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg">
                  <Edit2 size={18} />
                </button>
                <button onClick={() => { if(window.confirm('هل أنت متأكد من الحذف؟')) onDeleteItem(item.id); }} className="p-2 text-red-600 hover:bg-red-50 rounded-lg">
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
            
            <h3 className="font-bold text-lg text-gray-800 mb-1">{item.name}</h3>
            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded-md">{item.category}</span>
            
            <div className="mt-4 flex items-end justify-between">
              <div>
                <p className="text-sm text-gray-500 mb-1">الرصيد الحالي</p>
                <div className="flex items-baseline gap-1">
                  <span className={`text-2xl font-bold ${item.currentStock <= item.minStockLevel ? 'text-red-600' : 'text-gray-800'}`}>
                    {item.currentStock}
                  </span>
                  <span className="text-sm text-gray-400">{item.unit}</span>
                </div>
              </div>
              {item.currentStock <= item.minStockLevel && (
                <div className="flex items-center gap-1 text-red-600 bg-red-50 px-3 py-1 rounded-full text-xs font-bold animate-pulse">
                  <AlertTriangle size={14} />
                  <span>مخزون منخفض</span>
                </div>
              )}
            </div>
            
            <div className="mt-4 w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
               <div 
                 className={`h-full rounded-full ${item.currentStock <= item.minStockLevel ? 'bg-red-500' : 'bg-emerald-500'}`} 
                 style={{ width: `${Math.min((item.currentStock / (item.minStockLevel * 3)) * 100, 100)}%` }}
               ></div>
            </div>
          </div>
        ))}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-12 text-gray-400 bg-white rounded-2xl border border-dashed border-gray-200">
          <p>لا توجد أصناف مطابقة للبحث</p>
        </div>
      )}

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl animate-scale-in">
            <div className="flex justify-between items-center mb-6 border-b pb-4">
              <h3 className="text-xl font-bold">{editingItem ? 'تعديل صنف' : 'إضافة صنف جديد'}</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-gray-600">
                <X size={24} />
              </button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم الصنف</label>
                <input required type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-200 outline-none" 
                  value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">الفئة</label>
                  <input required type="text" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-200 outline-none" 
                    value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">الوحدة</label>
                  <input required type="text" placeholder="مثال: كجم، قطعة" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-200 outline-none" 
                    value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value})} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">حد الطلب (الأدنى)</label>
                    <input required type="number" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-200 outline-none" 
                    value={formData.minStockLevel} onChange={e => setFormData({...formData, minStockLevel: Number(e.target.value)})} />
                </div>
                {!editingItem && (
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">الرصيد الافتتاحي</label>
                        <input type="number" className="w-full p-3 rounded-lg border focus:ring-2 focus:ring-primary-200 outline-none" 
                        value={formData.currentStock} onChange={e => setFormData({...formData, currentStock: Number(e.target.value)})} />
                    </div>
                )}
              </div>
              
              <button type="submit" className="w-full bg-primary-600 text-white py-3 rounded-xl font-bold hover:bg-primary-700 transition flex justify-center items-center gap-2 mt-4">
                <Save size={20} />
                <span>حفظ البيانات</span>
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};