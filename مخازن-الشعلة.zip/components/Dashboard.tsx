import React, { useState, useEffect } from 'react';
import { AppData, ViewState } from '../types';
import { Package, AlertTriangle, ArrowDownLeft, ArrowUpRight, TrendingUp, Sparkles } from 'lucide-react';
import { getInventoryInsights } from '../services/geminiService';

interface DashboardProps {
  data: AppData;
  setView: (view: ViewState) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ data, setView }) => {
  const [insight, setInsight] = useState<string>('');
  const [loadingInsight, setLoadingInsight] = useState(false);

  const totalItems = data.items.length;
  const lowStockItems = data.items.filter(i => i.currentStock <= i.minStockLevel).length;
  const todayTransactions = data.transactions.filter(t => t.date === new Date().toISOString().split('T')[0]).length;
  const totalIn = data.transactions.filter(t => t.type === 'IN').reduce((acc, curr) => acc + curr.quantity, 0);
  const totalOut = data.transactions.filter(t => t.type === 'OUT').reduce((acc, curr) => acc + curr.quantity, 0);

  const StatCard = ({ title, value, icon, color, onClick }: any) => (
    <div onClick={onClick} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:shadow-md transition cursor-pointer flex items-center justify-between">
      <div>
        <p className="text-gray-500 text-sm font-medium mb-1">{title}</p>
        <h3 className="text-3xl font-bold text-gray-800">{value}</h3>
      </div>
      <div className={`p-4 rounded-full ${color}`}>
        {icon}
      </div>
    </div>
  );

  const fetchInsight = async () => {
    setLoadingInsight(true);
    const result = await getInventoryInsights(data);
    setInsight(result);
    setLoadingInsight(false);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <header className="flex justify-between items-center mb-6">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">لوحة التحكم</h2>
          <p className="text-gray-500">نظرة عامة على حالة المخزون اليوم</p>
        </div>
        <div className="text-left hidden sm:block">
            <span className="text-sm text-gray-400 bg-white px-3 py-1 rounded-full border shadow-sm">
                {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </span>
        </div>
      </header>

      {/* AI Insight Section */}
      <div className="bg-gradient-to-l from-indigo-50 to-purple-50 p-6 rounded-2xl border border-indigo-100">
        <div className="flex justify-between items-start">
            <div className="flex items-center gap-2 mb-2">
                <Sparkles className="text-purple-600" size={20} />
                <h3 className="font-bold text-indigo-900">المساعد الذكي</h3>
            </div>
            {!insight && !loadingInsight && (
                <button 
                    onClick={fetchInsight}
                    className="text-sm bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
                >
                    تحليل المخزون
                </button>
            )}
        </div>
        
        {loadingInsight && (
            <div className="animate-pulse flex space-x-4 space-x-reverse mt-2">
                <div className="flex-1 space-y-2 py-1">
                    <div className="h-2 bg-indigo-200 rounded"></div>
                    <div className="h-2 bg-indigo-200 rounded w-3/4"></div>
                </div>
            </div>
        )}

        {insight && (
            <div className="mt-2 text-indigo-800 leading-relaxed text-sm whitespace-pre-line">
                {insight}
            </div>
        )}
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="إجمالي الأصناف" 
          value={totalItems} 
          icon={<Package className="text-blue-600" size={24} />} 
          color="bg-blue-50"
          onClick={() => setView('INVENTORY')}
        />
        <StatCard 
          title="تنبيهات النواقص" 
          value={lowStockItems} 
          icon={<AlertTriangle className="text-red-600" size={24} />} 
          color="bg-red-50"
          onClick={() => setView('INVENTORY')}
        />
        <StatCard 
          title="حركة اليوم" 
          value={todayTransactions} 
          icon={<TrendingUp className="text-emerald-600" size={24} />} 
          color="bg-emerald-50"
          onClick={() => setView('REPORTS')}
        />
        <StatCard 
          title="صافي المخزون" 
          value={totalIn - totalOut} 
          icon={<Package className="text-orange-600" size={24} />} 
          color="bg-orange-50"
          onClick={() => setView('REPORTS')}
        />
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <div 
            onClick={() => setView('INBOUND')}
            className="group bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-primary-200 transition cursor-pointer flex items-center justify-between"
        >
            <div className="flex items-center gap-4">
                <div className="bg-emerald-100 p-4 rounded-xl group-hover:bg-emerald-200 transition">
                    <ArrowDownLeft className="text-emerald-700" size={28} />
                </div>
                <div>
                    <h3 className="font-bold text-lg text-gray-800">تسجيل وارد جديد</h3>
                    <p className="text-gray-500 text-sm">إضافة كميات جديدة للمخزون</p>
                </div>
            </div>
            <div className="text-gray-300 group-hover:text-emerald-600 group-hover:translate-x-[-5px] transition-transform">
                ➔
            </div>
        </div>

        <div 
            onClick={() => setView('OUTBOUND')}
            className="group bg-white p-6 rounded-2xl shadow-sm border border-gray-100 hover:border-primary-200 transition cursor-pointer flex items-center justify-between"
        >
            <div className="flex items-center gap-4">
                <div className="bg-orange-100 p-4 rounded-xl group-hover:bg-orange-200 transition">
                    <ArrowUpRight className="text-orange-700" size={28} />
                </div>
                <div>
                    <h3 className="font-bold text-lg text-gray-800">تسجيل منصرف جديد</h3>
                    <p className="text-gray-500 text-sm">صرف كميات لجهات أو مشاريع</p>
                </div>
            </div>
            <div className="text-gray-300 group-hover:text-orange-600 group-hover:translate-x-[-5px] transition-transform">
                ➔
            </div>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6 border-b border-gray-50 flex justify-between items-center">
            <h3 className="font-bold text-gray-800">آخر الحركات</h3>
            <button onClick={() => setView('REPORTS')} className="text-sm text-primary-600 hover:underline">عرض الكل</button>
        </div>
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-right">
                <thead className="bg-gray-50 text-gray-500">
                    <tr>
                        <th className="p-4 font-medium">الصنف</th>
                        <th className="p-4 font-medium">النوع</th>
                        <th className="p-4 font-medium">الكمية</th>
                        <th className="p-4 font-medium">الجهة</th>
                        <th className="p-4 font-medium">التاريخ</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                    {data.transactions.slice().reverse().slice(0, 5).map((t) => (
                        <tr key={t.id} className="hover:bg-gray-50 transition">
                            <td className="p-4 font-medium text-gray-800">{t.itemName}</td>
                            <td className="p-4">
                                <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                                    t.type === 'IN' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'
                                }`}>
                                    {t.type === 'IN' ? 'وارد' : 'منصرف'}
                                </span>
                            </td>
                            <td className="p-4 font-bold">{t.quantity}</td>
                            <td className="p-4 text-gray-500">{t.party}</td>
                            <td className="p-4 text-gray-400">{t.date}</td>
                        </tr>
                    ))}
                    {data.transactions.length === 0 && (
                        <tr>
                            <td colSpan={5} className="p-8 text-center text-gray-400">لا توجد حركات حديثة</td>
                        </tr>
                    )}
                </tbody>
            </table>
        </div>
      </div>
    </div>
  );
};