import React from 'react';
import { ViewState } from '../types';
import { LayoutDashboard, Package, ArrowDownLeft, ArrowUpRight, FileBarChart, Menu, X } from 'lucide-react';

interface SidebarProps {
  currentView: ViewState;
  setView: (view: ViewState) => void;
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, setView, isOpen, setIsOpen }) => {
  const menuItems = [
    { id: 'DASHBOARD', label: 'لوحة التحكم', icon: <LayoutDashboard size={20} /> },
    { id: 'INVENTORY', label: 'الأصناف (المخزون)', icon: <Package size={20} /> },
    { id: 'INBOUND', label: 'الوارد (إضافة)', icon: <ArrowDownLeft size={20} /> },
    { id: 'OUTBOUND', label: 'المنصرف (سحب)', icon: <ArrowUpRight size={20} /> },
    { id: 'REPORTS', label: 'التقارير', icon: <FileBarChart size={20} /> },
  ];

  const handleNav = (id: string) => {
    setView(id as ViewState);
    if (window.innerWidth < 768) {
      setIsOpen(false);
    }
  };

  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-20 md:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <div className={`
        fixed top-0 right-0 h-full bg-slate-900 text-white w-64 z-30 transform transition-transform duration-300 ease-in-out shadow-xl
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
        md:relative md:translate-x-0 no-print
      `}>
        <div className="p-6 flex justify-between items-center border-b border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
              <span className="font-bold text-white text-lg">ش</span>
            </div>
            <h1 className="text-xl font-bold text-primary-500">مخازن الشعلة</h1>
          </div>
          <button onClick={() => setIsOpen(false)} className="md:hidden text-slate-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        <nav className="mt-6 px-4 space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={`
                w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200
                ${currentView === item.id 
                  ? 'bg-primary-600 text-white shadow-lg shadow-primary-900/20' 
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'}
              `}
            >
              {item.icon}
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
        
        <div className="absolute bottom-0 w-full p-4 border-t border-slate-800">
          <p className="text-xs text-slate-500 text-center">الإصدار 1.0.0 &copy; 2024</p>
        </div>
      </div>
    </>
  );
};