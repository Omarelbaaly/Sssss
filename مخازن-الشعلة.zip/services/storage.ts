import { AppData, Item, Transaction } from '../types';

const STORAGE_KEY = 'SHOALA_INVENTORY_DATA';

const INITIAL_DATA: AppData = {
  items: [
    { id: '1', name: 'أسمنت مقاوم', category: 'مواد بناء', currentStock: 150, minStockLevel: 50, unit: 'كيس' },
    { id: '2', name: 'حديد تسليح 12مم', category: 'مواد بناء', currentStock: 30, minStockLevel: 20, unit: 'طن' },
    { id: '3', name: 'رمل ناعم', category: 'مواد بناء', currentStock: 200, minStockLevel: 100, unit: 'متر مكعب' },
    { id: '4', name: 'دهانات بلاستيك', category: 'تشطيبات', currentStock: 15, minStockLevel: 25, unit: 'جالون' },
  ],
  transactions: [
    { id: '101', itemId: '1', itemName: 'أسمنت مقاوم', type: 'IN', quantity: 200, date: '2023-10-01', party: 'شركة البناء الحديث' },
    { id: '102', itemId: '1', itemName: 'أسمنت مقاوم', type: 'OUT', quantity: 50, date: '2023-10-05', party: 'مشروع الفلل' },
    { id: '103', itemId: '2', itemName: 'حديد تسليح 12مم', type: 'IN', quantity: 50, date: '2023-10-10', party: 'مصنع الصلب' },
    { id: '104', itemId: '4', itemName: 'دهانات بلاستيك', type: 'OUT', quantity: 10, date: '2023-10-12', party: 'أعمال صيانة' },
  ]
};

export const loadData = (): AppData => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : INITIAL_DATA;
  } catch (error) {
    console.error("Failed to load data", error);
    return INITIAL_DATA;
  }
};

export const saveData = (data: AppData) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error("Failed to save data", error);
  }
};