import { GoogleGenAI } from "@google/genai";
import { AppData } from "../types";

export const getInventoryInsights = async (data: AppData): Promise<string> => {
  try {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      return "يرجى توفير مفتاح API للحصول على التحليل الذكي.";
    }

    const ai = new GoogleGenAI({ apiKey });
    
    // Prepare a summary for the AI
    const lowStockItems = data.items.filter(i => i.currentStock <= i.minStockLevel);
    const summary = {
      totalItems: data.items.length,
      lowStockCount: lowStockItems.length,
      lowStockNames: lowStockItems.map(i => i.name).join(', '),
      recentTransactions: data.transactions.slice(0, 5)
    };

    const prompt = `
      بصفتك مدير مخازن خبير، قم بتحليل بيانات المخزون التالية واكتب تقريراً قصيراً ومفيداً بالعربية (حوالي 3-4 جمل).
      ركز على النواقص والتوصيات.
      
      البيانات:
      ${JSON.stringify(summary)}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });

    return response.text || "لم يتم استلام رد من الذكاء الاصطناعي.";
  } catch (error) {
    console.error("AI Error:", error);
    return "حدث خطأ أثناء تحليل البيانات. تأكد من صحة المفتاح.";
  }
};