import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Inventory } from './components/Inventory';
import { TransactionForm } from './components/TransactionForm';
import { Reports } from './components/Reports';
import { AppData, Item, Transaction, ViewState } from './types';
import { loadData, saveData } from './services/storage';
import { Menu } from 'lucide-react';

const App: React.FC = () => {
  const [data, setData] = useState<AppData>(loadData());
  const [currentView, setView] = useState<ViewState>('DASHBOARD');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  useEffect(() => {
    saveData(data);
  }, [data]);

  // Handlers
  const handleAddItem = (newItem: Item) => {
    setData(prev => ({ ...prev, items: [...prev.items, newItem] }));
  };

  const handleUpdateItem = (updatedItem: Item) => {
    setData(prev => ({
      ...prev,
      items: prev.items.map(item => item.id === updatedItem.id ? updatedItem : item)
    }));
  };

  const handleDeleteItem = (id: string) => {
    setData(prev => ({
      ...prev,
      items: prev.items.filter(item => item.id !== id)
    }));
  };

  const handleTransaction = (txData: Omit<Transaction, 'id'>) => {
    const newTx: Transaction = {
      id: Date.now().toString(),
      ...txData
    };

    // Update stock
    const updatedItems = data.items.map(item => {
      if (item.id === txData.itemId) {
        return {
          ...item,
          currentStock: txData.type === 'IN' 
            ? item.currentStock + txData.quantity 
            : item.currentStock - txData.quantity
        };
      }
      return item;
    });

    setData(prev => ({
      items: updatedItems,
      transactions: [...prev.transactions, newTx]
    }));

    alert('تم حفظ العملية وتحديث المخزون بنجاح');
    setView('DASHBOARD');
  };

  const renderContent = () => {
    switch (currentView) {
      case 'DASHBOARD':
        return <Dashboard data={data} setView={setView} />;
      case 'INVENTORY':
        return <Inventory data={data} onAddItem={handleAddItem} onUpdateItem={handleUpdateItem} onDeleteItem={handleDeleteItem} />;
      case 'INBOUND':
        return <TransactionForm type="IN" data={data} onSubmit={handleTransaction} />;
      case 'OUTBOUND':
        return <TransactionForm type="OUT" data={data} onSubmit={handleTransaction} />;
      case 'REPORTS':
        return <Reports data={data} />;
      default:
        return <Dashboard data={data} setView={setView} />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col md:flex-row overflow-x-hidden">
      <Sidebar 
        currentView={currentView} 
        setView={setView} 
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
      />

      <main className="flex-1 p-4 md:p-8 w-full max-w-7xl mx-auto overflow-y-auto h-screen">
        {/* Mobile Header */}
        <div className="md:hidden flex items-center justify-between mb-6">
          <button onClick={() => setIsSidebarOpen(true)} className="p-2 bg-white rounded-lg shadow-sm text-slate-700">
            <Menu size={24} />
          </button>
          <h1 className="text-xl font-bold text-slate-800">مخازن الشعلة</h1>
          <div className="w-10" /> {/* Spacer */}
        </div>

        {renderContent()}
      </main>
    </div>
  );
};

export default App;