export interface Item {
  id: string;
  name: string;
  category: string;
  currentStock: number;
  minStockLevel: number;
  unit: string;
}

export type TransactionType = 'IN' | 'OUT';

export interface Transaction {
  id: string;
  itemId: string;
  itemName: string; // Denormalized for easier display if item deleted
  type: TransactionType;
  quantity: number;
  date: string;
  party: string; // Supplier for IN, Receiver for OUT
  notes?: string;
}

export interface AppData {
  items: Item[];
  transactions: Transaction[];
}

export type ViewState = 'DASHBOARD' | 'INVENTORY' | 'INBOUND' | 'OUTBOUND' | 'REPORTS';